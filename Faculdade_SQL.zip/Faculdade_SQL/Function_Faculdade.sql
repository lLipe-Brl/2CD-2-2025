USE db_faculdade;

-- Exercício 1: Crie uma função chamada idade_estudante que receba a data de
-- nascimento de um estudante e retorne à idade.
DELIMITER $$
CREATE FUNCTION idade_estudante(data_nasc DATE)
RETURNS INT
READS SQL DATA
BEGIN
DECLARE idade INT;
SET idade = TIMESTAMPDIFF(YEAR, data_nasc, CURDATE());
RETURN idade;
END$$
DELIMITER ;

SELECT idade_estudante('2000-07-20') AS idade;

-- Exercício 2: Crie uma função chamada total_estudantes_disciplina que receba o ID
-- de uma disciplina e retorne o número de estudantes matriculados nela.
DELIMITER $$
CREATE FUNCTION total_estudantes_disciplina(disciplina_id INT)
RETURNS INT
READS SQL DATA
BEGIN
    DECLARE total_estudantes INT;
    SELECT COUNT(*)
    INTO total_estudantes
    FROM matriculas
    WHERE id_diciplinaF = disciplina_id;
    RETURN total_estudantes;
END$$
DELIMITER ;
SELECT total_estudantes_disciplina(3) AS 'Total de Estudantes';

-- Exercício 3: Crie uma função chamada nota_maxima que retorne a maior nota
-- registrada na tabela notas.
DELIMITER $$

CREATE FUNCTION nota_maxima()
RETURNS DECIMAL(5,2)
READS SQL DATA
BEGIN
    DECLARE max_nota DECIMAL(5,2);
    SELECT MAX(nota)
    INTO max_nota
    FROM notas;
    RETURN max_nota;
END$$
DELIMITER ;


-- Exercício 4: Crie uma função chamada disciplina_do_curso que receba o ID de um
-- curso e retorne o nome da disciplina associada.
DELIMITER $$

CREATE FUNCTION disciplina_do_curso(curso_id INT)
RETURNS VARCHAR(1000)
READS SQL DATA
BEGIN
    DECLARE lista_disciplinas VARCHAR(1000);
    SELECT GROUP_CONCAT(nome SEPARATOR ', ')
    INTO lista_disciplinas
    FROM diciplinas
    WHERE id_cursoF = curso_id;
    RETURN lista_disciplinas;
END$$

DELIMITER ;

-- Exercício 5: Crie uma função chamada media_notas_curso que receba o ID de um
-- curso e retorne a média das notas dos estudantes matriculados nesse curso.

USE db_faculdade;
DELIMITER $$

CREATE FUNCTION media_notas_curso(curso_id INT)
RETURNS DECIMAL(5,2)
READS SQL DATA
BEGIN
    DECLARE media_curso DECIMAL(5,2);
    SELECT AVG(N.nota)
    INTO media_curso
    FROM notas AS N
    JOIN matriculas AS M ON N.id_matriculaF = M.id_matricula
    JOIN estudantes AS E ON M.id_estudanteF = E.id_estudante
    WHERE E.id_cursoF = curso_id;
    RETURN media_curso;
END$$

DELIMITER ;







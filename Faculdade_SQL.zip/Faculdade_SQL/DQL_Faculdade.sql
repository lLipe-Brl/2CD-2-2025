USE db_faculdade;

SELECT * FROM matriculas;
-- Desativar checagem de chave estrangeira
SET FOREIGN_KEY_CHECKS = 0;
-- Reativar checagem de chave estrangeira
SET FOREIGN_KEY_CHECKS = 1;

-- Exercício 1: Liste todos os estudantes cadastrados na tabela estudantes que
-- pertencem ao curso de Ciência de Dados e foram matriculados em 2024.

SELECT * FROM estudantes AS E
INNER JOIN
cursos AS C
ON E.id_cursoF = C.id_curso
WHERE C.nome = 'Data Science' AND YEAR(e.data_matricula) = 2023;

-- Exercício 2: Liste todos os professores que pertencem ao departamento de Ciência
-- da Computação e possuem mais de 5 anos de experiência.

SELECT * FROM professores
WHERE departamento = 'Tecnologia' AND 
TIMESTAMPDIFF(YEAR, ano_admissao, CURDATE()) > 5;

-- Exercício 3: Liste os nomes dos estudantes e suas notas nas disciplinas, ordenados
-- pela nota em ordem decrescente e, em caso de empate, pelo nome do estudante
-- em ordem alfabética.

SELECT E.nome, n.nota
FROM estudantes AS E
INNER JOIN
matriculas AS M ON E.id_estudante = M.id_estudanteF
INNER JOIN
notas AS N ON M.id_matricula = N.id_matriculaF
ORDER BY N.nota DESC, E.nome ASC;

-- Exercício 4: Encontre a média das notas dos estudantes no curso de Engenharia de
-- Software.

SELECT AVG(n.nota) AS 'Média das Notas em Data Science'
FROM notas AS N
LEFT JOIN matriculas AS M ON N.id_matriculaF = M.id_matricula
LEFT JOIN estudantes AS E ON M.id_estudanteF = E.id_estudante
LEFT JOIN cursos AS C ON E.id_cursoF = C.id_curso
WHERE C.nome = 'Data Science';

-- Exercício 5: Liste os cursos que possuem mais de 5 estudantes matriculados.
-- Exiba o nome do curso e o total de estudantes matriculados.

SELECT
C.nome AS nome_do_curso,
COUNT(E.id_estudante) AS total_de_estudantes
FROM cursos C
JOIN estudantes E ON E.id_cursoF = C.id_curso
GROUP BY C.id_curso, C.nome
ORDER BY total_de_estudantes DESC;
    
    
    
    

CREATE DEFINER=`root`@`localhost` TRIGGER `notas_BEFORE_INSERT` BEFORE INSERT ON `notas` FOR EACH ROW BEGIN
    IF NEW.nota > 10.00 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Erro: A nota não pode ser superior a 10.';
    END IF;
END
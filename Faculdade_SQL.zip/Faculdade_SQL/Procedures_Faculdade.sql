USE db_faculdade;
-- Exercício 1: Crie uma procedure chamada insere_professor que insere um professor
-- na tabela professores e retorna o ID gerado.
DELIMITER $$

CREATE PROCEDURE insere_professor(
    IN p_nome VARCHAR(100),
    IN p_departamento VARCHAR(100),
    IN p_ano_admissao DATE,
    OUT p_id_gerado INT
)
BEGIN
    -- Insere os dados na tabela professores
    INSERT INTO professores(nome, departamento, ano_admissao)
    VALUES (p_nome, p_departamento, p_ano_admissao);

    -- Obtém o último ID gerado pela inserção e o atribui ao parâmetro de saída
    SET p_id_gerado = LAST_INSERT_ID();
END$$

DELIMITER ;

-- Exercício 2: Crie uma procedure chamada atualiza_disciplina que recebe o ID de
-- uma disciplina e atualiza o nome dessa disciplina.

USE db_faculdade;

DELIMITER $$

CREATE PROCEDURE atualiza_disciplina(
    IN p_id_diciplina INT,
    IN p_novo_nome VARCHAR(100)
)
BEGIN
    UPDATE diciplinas
    SET nome = p_novo_nome
    WHERE id_diciplina = p_id_diciplina;
END$$

DELIMITER ;

-- Exercício 3: Crie uma procedure chamada remove_estudante que remove um
-- estudante da tabela estudantes com base no ID passado como parâmetro.

USE db_faculdade;

DELIMITER $$

CREATE PROCEDURE remove_estudante(
    IN p_id_estudante INT
)
BEGIN
    DELETE FROM estudantes
    WHERE id_estudante = p_id_estudante;
END$$

DELIMITER ;

-- Exercício 4: Crie uma procedure chamada consulta_professor que retorna o nome e
-- departamento de um professor com base no ID passado. 

USE db_faculdade;

DELIMITER $$

CREATE PROCEDURE consulta_professor(
    IN p_id_professor INT
)
BEGIN
    SELECT nome, departamento
    FROM professores
    WHERE id_professor = p_id_professor;
END$$

DELIMITER ;

-- Exercício 5: Crie uma procedure chamada atualiza_nota que atualiza a nota de um
-- estudante para uma disciplina específica, com base no ID da matrícula.

USE db_faculdade;

DELIMITER $$

CREATE PROCEDURE atualiza_nota(
    IN p_id_matricula INT,
    IN p_nova_nota DECIMAL(5,2)
)
BEGIN
    UPDATE notas
    SET
        nota = p_nova_nota,
        data_lancamento = CURDATE()
    WHERE id_matriculaF = p_id_matricula;
END$$

DELIMITER ;





CREATE DATABASE db_faculdade;

USE db_faculdade;

CREATE TABLE cursos(
id_curso INT AUTO_INCREMENT,
nome VARCHAR(100),
duracao_anos INT,
PRIMARY KEY (id_curso)
);

CREATE TABLE professores(
id_professor INT AUTO_INCREMENT,
nome VARCHAR(100),
departamento VARCHAR(100),
PRIMARY KEY (id_professor),
ano_admissao DATE
);

CREATE TABLE diciplinas(
id_diciplina INT AUTO_INCREMENT,
nome VARCHAR(100),
id_cursoF INT,
departamento INT,
FOREIGN KEY (id_cursoF) REFERENCES cursos (id_curso),
PRIMARY KEY (id_diciplina)
);

CREATE TABLE estudantes(
id_estudante INT AUTO_INCREMENT,
nome VARCHAR(100),
data_nascimento DATE,
departamento INT,
email VARCHAR(100),
id_cursoF INT,
data_matricula DATE,
FOREIGN KEY (id_cursoF) REFERENCES cursos (id_curso),
PRIMARY KEY (id_estudante)
);

CREATE TABLE matriculas(
id_matricula INT AUTO_INCREMENT,
id_estudanteF INT,
FOREIGN KEY (id_estudanteF) REFERENCES estudantes (id_estudante),
id_diciplinaF INT,
FOREIGN KEY (id_diciplinaF) REFERENCES diciplinas (id_diciplina),
data_matricula DATE,
PRIMARY KEY (id_matricula)
);

CREATE TABLE notas(
id_nota INT AUTO_INCREMENT,
id_matriculaF INT,
FOREIGN KEY (id_matriculaF) REFERENCES matriculas (id_matricula),
nota DECIMAL(5,2),
data_lancamento DATE,
PRIMARY KEY (id_nota)
);



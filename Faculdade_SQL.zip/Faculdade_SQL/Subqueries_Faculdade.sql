-- Exercício 1: Liste os cursos que possuem mais de 5 disciplinas associadas.
USE db_faculdade;
SELECT C.nome AS nome_do_curso,
Contagem.total_de_disciplinas FROM cursos C
JOIN(SELECT id_cursoF, COUNT(id_diciplina) AS total_de_disciplinas
FROM diciplinas GROUP BY id_cursoF) 
AS Contagem ON C.id_curso = Contagem.id_cursoF
WHERE Contagem.total_de_disciplinas > 5;

-- Exercício 2: Liste os estudantes que estão matriculados em mais disciplinas do que
-- a média de disciplinas por estudante.

WITH ContagemPorCurso AS 
(SELECT c.nome, COUNT(d.id_diciplina) AS total_disciplinas
FROM cursos c JOIN diciplinas d ON c.id_curso = d.id_cursoF
GROUP BY c.id_curso, c.nome)

SELECT nome AS cursos,
total_disciplinas,
ROUND(AVG(total_disciplinas) OVER(), 2) AS media_geral_disciplinas
FROM ContagemPorCurso
WHERE total_disciplinas > 5;

-- Exercício 3: Encontre os professores que ministram disciplinas com a maior média
-- de notas.

-- Exemplo: Atribui o professor de id=1 à disciplina de id=1
UPDATE diciplinas SET id_professorF = 1 WHERE id_diciplina = 1;
WITH RankingDasDisciplinas AS 
(SELECT p.nome AS nome_professor,
d.nome AS nome_disciplina,
AVG(n.nota) AS media_da_disciplina,
RANK() OVER (ORDER BY AVG(n.nota) DESC) as ranking
FROM professores p
JOIN diciplinas d ON p.id_professor = d.id_professorF
JOIN matriculas m ON d.id_diciplina = m.id_diciplinaF
JOIN notas n ON m.id_matricula = n.id_matriculaF
GROUP BY p.id_professor, d.id_diciplina
)
SELECT nome_professor,
nome_disciplina, media_da_disciplina
FROM RankingDasDisciplinas
WHERE ranking = 1;

-- Exercício 4: Liste os estudantes que possuem pelo menos uma nota abaixo da
-- média geral de notas.

SELECT DISTINCT
E.nome AS nome_do_estudante
FROM estudantes AS E
JOIN matriculas AS M ON E.id_estudante = M.id_estudanteF
JOIN notas AS N ON M.id_matricula = N.id_matriculaF
WHERE N.nota < (SELECT AVG(nota) FROM notas);

-- Exercício 5: Liste os professores que não possuem nenhuma disciplina com notas
-- abaixo de 7.

USE db_faculdade;

SELECT P.nome
FROM professores AS P
WHERE P.id_professor NOT IN (
SELECT DISTINCT D.id_professorF
FROM diciplinas AS D
JOIN matriculas AS M ON D.id_diciplina = M.id_diciplinaF
JOIN notas AS N ON M.id_matricula = N.id_matriculaF
WHERE N.nota < 7.0);

-- Exercício 1: Crie uma função chamada idade_estudante que receba a data de
-- nascimento de um estudante e retorne à idade.









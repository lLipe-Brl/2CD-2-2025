USE db_faculdade;
SELECT * FROM professores;

-- Inserindo dados na tabela 'cursos'
INSERT INTO cursos (nome, duracao_anos) VALUES
('Ciência da Computação', 4),
('Engenharia Elétrica', 5);

-- Inserindo dados na tabela 'professores'
INSERT INTO professores (nome, departamento, ano_admissao) VALUES
('Dr. Carlos Silva', 'Tecnologia', '2010-03-15'),
('Dra. Ana Pereira', 'Engenharia', '2012-08-21'),
('Dr. João Souza', 'Negócios', '2015-02-10'),
('Dra. Maria Oliveira', 'Ciências Jurídicas', '2008-11-01'),
('Dr. Pedro Costa', 'Ciências da Saúde', '2014-07-30');

-- Inserindo dados na tabela 'diciplinas'
-- Associando as disciplinas aos cursos criados anteriormente
INSERT INTO diciplinas (nome, id_cursoF, departamento) VALUES
( 'Banco de Dados', 1, 1),
( 'Algoritmos', 1, 1),
( 'Estruturas de Dados', 1, 1),
( 'Inteligência Artificial', 1, 1),
( 'Programação Web', 1, 1),
( 'Sistemas Operacionais', 1, 1);

UPDATE diciplinas
SET nome = 'Fundamentos de Engenharia'
WHERE id_diciplina = 5;

-- Inserindo dados na tabela 'estudantes'
-- Associando os estudantes aos cursos
INSERT INTO estudantes (nome, data_nascimento, email, id_cursoF, data_matricula) VALUES
('Laura Ramos', '2000-07-20', 'eduardalima@email.com', 5, '2020-02-01'),
('Gustavo Souza', '2000-07-20', 'eduardalima@email.com', 5, '2020-02-01'),
('Lucas Luiz', '2000-07-20', 'eduardalima@email.com', 5, '2020-02-01'),
('Guilherme Rocha', '2000-07-20', 'eduardalima@email.com', 5, '2020-02-01');

-- Inserindo dados na tabela 'matriculas'
-- Matriculando os estudantes nas disciplinas
INSERT INTO matriculas (id_estudanteF, id_diciplinaF, data_matricula) VALUES
(1, 6, '2023-02-01'),
(2, 2, '2022-02-01'),
(3, 3, '2024-02-01'),
(4, 4, '2021-02-01'),
(5, 5, '2020-02-01'),
(6, 3, '2020-02-01');

-- Inserindo dados na tabela 'notas'
-- Lançando as notas para as matrículas correspondentes
INSERT INTO notas (id_matriculaF, nota, data_lancamento) VALUES
(1, 8.5, '2023-06-15'),
(2, 9.0, '2023-11-20'),
(3, 7.8, '2022-06-18'),
(4, 9.5, '2024-06-25'),
(5, 8.2, '2021-06-14');
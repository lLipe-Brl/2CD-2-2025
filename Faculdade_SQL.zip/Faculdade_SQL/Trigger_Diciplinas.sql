CREATE DEFINER=`root`@`localhost` TRIGGER `diciplinas_BEFORE_DELETE` BEFORE DELETE ON `diciplinas` FOR EACH ROW BEGIN
	DECLARE num_matriculas INT;

    -- Conta quantas matrículas existem para a disciplina que está sendo deletada
    SELECT COUNT(*)
    INTO num_matriculas
    FROM matriculas
    WHERE id_diciplinaF = OLD.id_diciplina;

    -- Se a contagem for maior que 0, impede a exclusão
    IF num_matriculas > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Erro: Não é possível excluir disciplinas com estudantes matriculados.';
    END IF;
END
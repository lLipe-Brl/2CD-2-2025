CREATE DEFINER=`root`@`localhost` TRIGGER `matriculas_BEFORE_INSERT` BEFORE INSERT ON `matriculas` FOR EACH ROW BEGIN
	SET NEW.data_matricula = CURDATE();
END